import { load } from "../lib/common.mjs";

// Jeden Montag 00:00 UTC: load() erkennt die neue Woche, kuert den Gewinner und setzt zurueck
export default async () => { await load(); };
export const config = { schedule: "0 0 * * 1" };
