import { tg, SECRET } from "../lib/common.mjs";

// Einmalig aufrufen: https://DEINE-SEITE.netlify.app/api/setup?key=DEIN_WEBHOOK_SECRET
export default async (req) => {
  const url = new URL(req.url);
  if (url.searchParams.get("key") !== SECRET) return new Response("forbidden", { status: 403 });
  const wh = await tg("setWebhook", {
    url: `${url.origin}/api/bot`,
    secret_token: SECRET,
    allowed_updates: ["message", "chat_member"],
  });
  const mb = await tg("setChatMenuButton", { menu_button: { type: "web_app", text: "Rennen", web_app: { url: url.origin } } });
  const me = await tg("getMe");
  return Response.json({ webhook: wh, menuButton: mb, bot: me.result?.username });
};

export const config = { path: "/api/setup" };
