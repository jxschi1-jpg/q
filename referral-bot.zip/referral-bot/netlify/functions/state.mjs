import { load, save, ranking, checkInitData, nextReset, BOT_USERNAME, OWNER, CHANNEL_URL } from "../lib/common.mjs";

export default async (req) => {
  const { initData } = await req.json().catch(() => ({}));
  const user = checkInitData(initData);
  if (!user) return Response.json({ error: "auth" }, { status: 401 });
  const s = await load();
  const id = String(user.id);
  s.names[id] = user.first_name || user.username || "User";
  if (!s.users[id]) s.users[id] = { t: Date.now() };
  await save(s);
  const r = ranking(s);
  return Response.json({
    top: r.slice(0, 10).map((x, i) => ({ rank: i + 1, name: x.name, n: x.n })),
    me: {
      count: s.counts[id]?.n || 0,
      rank: r.findIndex((x) => x.id === id) + 1 || null,
      link: `https://t.me/${BOT_USERNAME}?start=ref_${id}`,
    },
    resetAt: nextReset(),
    lastWinner: s.lastWinner,
    owner: OWNER,
    channel: CHANNEL_URL,
  });
};

export const config = { path: "/api/state" };
