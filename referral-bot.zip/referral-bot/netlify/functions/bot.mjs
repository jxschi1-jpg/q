import { tg, load, save, SECRET, CHANNEL, CHANNEL_URL, BOT_USERNAME } from "../lib/common.mjs";

const IN = ["member", "administrator", "creator"];

async function onStart(m, s) {
  const id = String(m.from.id);
  s.names[id] = m.from.first_name || m.from.username || "User";
  const arg = (m.text.split(" ")[1] || "");
  if (!s.users[id]) {
    s.users[id] = { t: Date.now() };
    const ref = arg.startsWith("ref_") ? arg.slice(4) : "";
    // Referrer muss existieren, kein Selbst-Referral
    if (ref && ref !== id && s.users[ref]) s.users[id].ref = ref;
  }
  const u = s.users[id];
  if (!u.link || s.credited[id]) {
    const r = await tg("createChatInviteLink", { chat_id: CHANNEL, name: `u${id}`, member_limit: 1 });
    u.link = r.result?.invite_link || CHANNEL_URL;
  }
  const appUrl = process.env.URL || process.env.APP_URL || "";
  const myLink = `https://t.me/${BOT_USERNAME}?start=ref_${id}`;
  await tg("sendMessage", {
    chat_id: m.chat.id,
    text:
      `👋 Willkommen!\n\nTritt unserem Kanal bei und nimm am wöchentlichen Referral-Rennen teil. ` +
      `Wer pro Woche die meisten Einladungen hat, gewinnt 1 Produkt seiner Wahl!\n\n` +
      `🔗 Dein Referral-Link:\n${myLink}`,
    reply_markup: {
      inline_keyboard: [
        [{ text: "📢 Kanal beitreten", url: u.link }],
        ...(appUrl ? [[{ text: "🏁 Rennen öffnen", web_app: { url: appUrl } }]] : []),
      ],
    },
  });
}

async function onMember(cm, s) {
  if ((cm.chat.username || "").toLowerCase() !== CHANNEL.replace("@", "").toLowerCase()) return;
  const uid = String(cm.new_chat_member.user.id);
  const now = IN.includes(cm.new_chat_member.status);
  const was = IN.includes(cm.old_chat_member.status) || cm.old_chat_member.is_member;
  if (now && !was) {
    const u = s.users[uid];
    // Zaehlt nur: Bot per Ref-Link gestartet + Beitritt ueber den eigenen Einladungslink
    if (u?.ref && cm.invite_link?.name === `u${uid}` && !s.credited[uid]) {
      s.credited[uid] = { ref: u.ref, week: s.week, active: true };
      const c = (s.counts[u.ref] ??= { n: 0, t: 0 });
      c.n++; c.t = Date.now();
      await tg("sendMessage", { chat_id: u.ref, text: `🎉 ${cm.new_chat_member.user.first_name} ist über deinen Link beigetreten! Du hast jetzt ${c.n} Referrals.` });
    }
  } else if (!now && was) {
    const c = s.credited[uid];
    if (c?.active) {
      c.active = false;
      if (c.week === s.week && s.counts[c.ref]) s.counts[c.ref].n = Math.max(0, s.counts[c.ref].n - 1);
    }
  }
}

export default async (req) => {
  if (req.headers.get("x-telegram-bot-api-secret-token") !== SECRET) return new Response("forbidden", { status: 403 });
  const upd = await req.json();
  try {
    const s = await load();
    if (upd.message?.text?.startsWith("/start")) await onStart(upd.message, s);
    else if (upd.chat_member) await onMember(upd.chat_member, s);
    await save(s);
  } catch (e) { console.error(e); }
  return new Response("ok");
};

export const config = { path: "/api/bot" };
